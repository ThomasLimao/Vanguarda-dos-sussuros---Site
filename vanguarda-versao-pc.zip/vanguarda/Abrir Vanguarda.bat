@echo off
setlocal enabledelayedexpansion
set "ARQ=%~dp0Vanguarda-dos-Sussurros.html"
set "URL=file:///%ARQ:\=/%"
set "URL=!URL: =%%20!"

set "BRAVE=%ProgramFiles%\BraveSoftware\Brave-Browser\Application\brave.exe"
if not exist "%BRAVE%" set "BRAVE=%LocalAppData%\BraveSoftware\Brave-Browser\Application\brave.exe"
if not exist "%BRAVE%" goto padrao

start "" "%BRAVE%" --app="!URL!"
goto fim

:padrao
start "" "%ARQ%"

:fim
endlocal
